import React from 'react'
import Services1 from '../components/Services1'
import PackagesSection from '../components/PackagesSection'
const Services = () => {
  return (
    <>
    <Services1 />
    <PackagesSection/>
    
    </>
  )
}

export default Services